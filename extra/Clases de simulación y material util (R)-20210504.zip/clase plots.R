Pima<-read.csv("diabetes.csv")
#gráficos básicos usando el paquete que ya viene de plots
names(Pima)[7]<-"DPF" #le cambio el nombre a la variable porque es muy largo
attach(Pima) #hago que R entienda los nombres de las variables como vectores


#grafico de barras con etiquetas
tabla<-table(Outcome)
bp<-barplot(tabla, xlab = "Outcome", ylab = "Frequencia absoluta",main="Barplot")
text(x=bp, tabla, labels=round(tabla,0), pos=3, xpd=NA)


#boxplot
boxplot(BMI, main= "BMI (índice de masa corporal)")

#histograma
hist(BMI,freq = FALSE, main= "Histograma BMI", labels=TRUE)

#grafico de dispersion
plot(BMI,Age, pch=20,col="darkblue",
     xlab="BMI",ylab="Age", main = "Gráfico de dispersión")



#agregamos graficos superpuestos
plot(BMI,Age, pch=20,col="darkblue",
     xlab="BMI",ylab="Age", main = "Gráfico de dispersión")
abline(h=50, col="red")
abline(v=23, col="green")
points(BMI,Age, lty=1:5, col=1:4)


#varios gráficos por hoja
par(mfrow=c(2, 2)) 
hist(BMI,freq = FALSE, main= "Histograma 1", col="skyblue")
hist(BMI,freq = FALSE, main= "Histograma 2", col="chocolate")
par(mfrow=c(1,1))

#gráfico de mosaicos
Edad<-ifelse(Age<30,"Joven", ifelse(Age<50, "Adulto", "Mayor"))
tabla<-table(Outcome,Edad)
mosaicplot(tabla, main="Gráfico de mosaicos", col=c("mediumpurple3", "chocolate", "skyblue"))

#otro para agregar leyenda
a<-c(1:5)
b<-c(5,3,4,5,5)
c<-c(4,5,4,3,1)


plot( a,b, type="b" , bty="l" , xlab="x" , 
      ylab="y" , col=rgb(0.2,0.4,0.1,0.7) , lwd=3 , pch=17 , ylim=c(1,5) )
lines(a,c , col=rgb(0.8,0.4,0.1,0.7) , lwd=3 , pch=19 , type="b" )

# Agregamos leyenda
legend("bottomleft", 
       legend = c("Grupo 1", "Grupo 2"), 
       col = c(rgb(0.2,0.4,0.1,0.7), 
               rgb(0.8,0.4,0.1,0.7)), 
       pch = c(17,19), 
       bty = "n", 
       pt.cex = 2, 
       cex = 1.2, 
       text.col = "black", 
       horiz = F , 
       inset = c(0.1, 0.1))



#scatter plot: todos vs todos
plot(Pima[,1:4], pch=20)


#Gráfico de torta

#Grafico de torta
tabla2<-as.data.frame(table(Edad))
pie(tabla2$Freq, labels = tabla2$Edad, main="Edades")

#Cambio tamaño del gráfico
pie(tabla2$Freq, labels = tabla2$Edad, main="Tortas grandes" , radius=10)
pie(tabla2$Freq, labels = tabla2$Edad, main="Tortas chicas" , radius=0.2)

#Cambio colores y bordes

pie(tabla2$Freq, labels = tabla2$Edad,
    border="grey", col=c("mediumpurple3", "chocolate", "skyblue"))
pie(tabla2$Freq, labels = tabla2$Edad,
    border="grey", col=terrain.colors(3))





#ahora ggplot2
#cambiamos de set de datos
data("mtcars")
attach(mtcars)
library(ggplot2)

#graficos de puntos
qplot(mpg, wt, data = mtcars)
qplot(mpg, wt, data = mtcars, geom = c("point", "smooth"))


# Cambiar color según una variable factor o numérica
qplot(mpg, wt, data = mtcars, color = factor(cyl))
qplot(mpg, wt, data = mtcars, colour = hp)


# Agregar lineas
qplot(mpg, wt, data = mtcars, colour = factor(cyl),
      geom=c("point", "line"))

# Cambiar el tamaño de los puntos según una variable
qplot(mpg, wt, data = mtcars, size = mpg)

qplot(mpg, wt, data = mtcars, shape = factor(cyl))


#nombrar los puntos según el nombre de la fila
qplot(mpg, wt, data = mtcars, label = rownames(mtcars), 
      geom=c("point", "text"),
      hjust=0, vjust=0)

# Box plot
qplot(factor(cyl), mpg, data=mtcars,geom="boxplot",
      col=factor(cyl))

# Dot plot
qplot(factor(cyl), mpg, data=mtcars, 
      geom=c("dotplot"), 
      stackdir = "center", binaxis = "y")

# Violin plot
qplot(factor(cyl), mpg, data=mtcars, 
      geom=c("violin"), trim = FALSE)


qplot(factor(cyl), mpg, data=mtcars, 
      geom=c("boxplot", "jitter"), fill = factor(cyl))



#ahora con ggplot

library(ggplot2)

# Grafico de barras

tabla<-as.data.frame(table(cyl))
p<-ggplot(data=tabla, aes(x=cyl, y=Freq)) +
  geom_bar(stat="identity", fill=c("mediumpurple3", "chocolate", "skyblue"))+
  theme_minimal()
p


#o sin la tabla
ggplot(mtcars, aes(x=factor(cyl)))+
  geom_bar(stat="count", width=0.7, fill=c("mediumpurple3", "chocolate", "skyblue"))+
  theme_light()
 


#si quiero de proporciones
ggplot(mtcars, aes(x=cyl))+
  geom_bar(aes(y=..prop..),stat="count", 
        fill=c("mediumpurple3", "chocolate", "skyblue"))+
  geom_text(aes( label = ..prop..,
                 y= ..prop.. ), stat= "count", vjust = -.5)+
  theme_light()




# Barras horizontales
p + coord_flip()


# Cambio el ancho de las barras
ggplot(data=tabla, aes(x=cyl, y=Freq)) +
  geom_bar(stat="identity", width=0.5)


# Cambio el fondo y el color
ggplot(data=tabla, aes(x=cyl, y=Freq)) +
  geom_bar(stat="identity", fill="steelblue")+
  theme_minimal()



# Texto afuera de las barras
ggplot(data=tabla, aes(x=cyl, y=Freq)) +
  geom_bar(stat="identity", fill="steelblue")+
  geom_text(aes(label=Freq), vjust=-0.3, size=3.5)

# Texto adentro
ggplot(data=tabla, aes(x=cyl, y=Freq)) +
  geom_bar(stat="identity", fill="steelblue")+
  geom_text(aes(label=Freq), vjust=1.6, color="white", size=3.5)


# Mas formatos...
ggplot(data=tabla, aes(x=cyl, y=Freq, color=cyl)) +
  geom_bar(stat="identity", fill="white")

ggplot(data=tabla, aes(x=cyl, y=Freq, fill=cyl)) +
  geom_bar(stat="identity")



# CCambio las leyendas de lugar
p + theme(legend.position="top")
p + theme(legend.position="bottom")
# Remove legend
p + theme(legend.position="none")


tabla2<-as.data.frame(table(vs,cyl))

# Barras apiladas con mas grupos

ggplot(data=tabla2, aes(x=cyl, y=Freq, fill=vs)) +
  geom_bar(stat="identity")

# las pongo al lado position=position_dodge()
ggplot(data=tabla2, aes(x=cyl, y=Freq, fill=vs)) +
  geom_bar(stat="identity", position=position_dodge())


#agregamos etiquetas (labels)
ggplot(data=tabla2, aes(x=cyl, y=Freq, fill=vs)) +
  geom_bar(stat="identity", position=position_dodge())+
  geom_text(aes(label=Freq), vjust=1.6, color="white",
            position = position_dodge(0.9), size=3.5)+
  scale_fill_brewer(palette="Paired")+
  theme_minimal()


ggplot(mtcars, aes(x=rownames(mtcars),y=mpg)) + 
  geom_bar(stat="identity", width=.5, fill="tomato3",position=position_dodge()) + 
  theme(axis.text.x = element_text(angle=65, vjust=0.6))



#Grafico de torta
tabla<-as.data.frame(table(cyl))
bp<-ggplot(data=tabla, aes(x="", y=Freq, fill=cyl)) +
  geom_bar(width = 1,stat="identity")

pie <- bp + coord_polar("y", start=0)
pie

pie + scale_fill_brewer(palette="Dark2")


#Grafico de donas
tabla$fraction = tabla$Freq / sum(tabla$Freq)
tabla = tabla[order(tabla$fraction), ]
tabla$ymax = cumsum(tabla$fraction)
tabla$ymin = c(0, head(tabla$ymax, n=-1))
ggplot(tabla, aes(fill=cyl, ymax=ymax, ymin=ymin, xmax=4, xmin=3)) +
  geom_rect() +
  coord_polar(theta="y") +
  xlim(c(0, 4)) +
  labs(title="Basic ring plot")


#graficos de dispersión
#scatterplot

g <- ggplot(mtcars, aes(x=mpg, y=disp)) + geom_point() 
g #puedo hacer mas millas por galon si el motor es pequeño

g+ geom_smooth(method="lm", se=FALSE)  # set se=FALSE to turnoff confidence bands

#ajusto los ejes
g + xlim(c(0, 0.1)) + ylim(c(0, 1000000))

# Add Title and Labels
g + labs(title="Consumo Vs Volumen del motor", subtitle="Acá puede ir un subtitulo", 
         y="Engine displacement", x="mpg", caption="Acá un pie de gráfico")


#cambiar los colores

g+ geom_point(col="steelblue", size=3) +   # Set static color and size for points
  geom_smooth(method="lm", col="firebrick")  # change the color of line

#colores segun otra categoría

g+ geom_point(aes(col=factor(cyl)), size=3)  # Set color to vary based on state categories.

#con otra paleta de colores

g + scale_colour_brewer(palette = "Set1") + geom_point(aes(col=factor(cyl)), size=3) 


#boxplot

g <- ggplot(mtcars, aes(x= factor(cyl), y=mpg))
g + geom_boxplot(fill="steelblue") + 
  labs(title="Box plot",
       caption="Source: mtcars",
       x="Número de cilindros",
       y="Mpg")


#histogramas

library(gridExtra) #para hacer muchos graficos en una hoja

bufalo<-scan("buffalo.txt")
datos<-data.frame("nieve"= bufalo)

# Histograma moviendo x0
g1<-ggplot(datos, aes(X1)) + 
  geom_histogram(aes(x=nieve,y = ..density..),binwidth = 2,alpha=0.5, 
                 fill = "mediumpurple3", color = "black",
                 breaks =seq(20,130,10)) + 
  theme_light()

g2<-ggplot(datos, aes(X1)) + 
  geom_histogram(aes(x=nieve,y = ..density..),binwidth = 2,alpha=0.5, 
                 fill = "mediumpurple3", color = "black",
                 breaks =seq(22,132,10)) + 
  theme_light()

g3<-ggplot(datos, aes(X1)) + 
  geom_histogram(aes(x=nieve,y = ..density..),binwidth = 2,alpha=0.5, 
                 fill = "mediumpurple3", color = "black",
                 breaks =seq(24,134,10)) + 
  theme_light()

g4<-ggplot(datos, aes(X1)) + 
  geom_histogram(aes(x=nieve,y = ..density..),binwidth = 2,alpha=0.5, 
                 fill = "mediumpurple3", color = "black",
                 breaks =seq(26,136,10)) + 
  theme_light()


grid.arrange(g1, g2, g3,g4, nrow = 2)


ggplot(mtcars, aes(mpg)) + 
  geom_histogram(aes(x=mpg,y = ..density..),binwidth = 2,alpha=1, 
                 fill = "skyblue", color = "black") + 
  labs(title="Histograma + densidad")+ geom_density(lwd=1.5)


#Función empírica y distribución

ggplot(mtcars, aes(mpg)) + stat_ecdf(geom = "step")+
  labs(title="Distribución empírica",y = "F", x= "mpg")


library(gridExtra)

# Con otros graficos
g1<-ggplot(mtcars, aes(x=qsec)) + geom_density(fill="slateblue")
g2<-ggplot(mtcars, aes(x=drat, y=qsec, color=cyl)) + geom_point(size=5) + theme(legend.position="none")
g3<-ggplot(mtcars, aes(x=factor(cyl), y=qsec, fill=cyl)) + geom_boxplot() + theme(legend.position="none")
g4<-ggplot(mtcars , aes(x=factor(cyl), fill=factor(cyl))) +  geom_bar()

# Vemos los 4 en la misma pagina
grid.arrange(g1, g2, g3, g4, ncol=2, nrow =2)

# Plots
grid.arrange(g2, arrangeGrob(g3, g4, ncol=2), nrow = 2)
grid.arrange(g1, g2, g3, nrow = 3)
grid.arrange(g2, arrangeGrob(g3, g4, ncol=2), nrow = 1)
grid.arrange(g2, arrangeGrob(g3, g4, nrow=2), nrow = 1)


library(GGally)
mtcars$vs<-as.factor(mtcars$vs)
mtcars$am<-as.factor(mtcars$am)

ggpairs(mtcars[,c(1,3,4,8)], mapping=ggplot2::aes(colour = vs))

ggpairs(mtcars[,c(1,3,4,8)],colour= "skyblue")

#sobrevida
library(survival)
library(survminer)

sobrevida<-scan()
48  48 101  12  55 112 111  48  48  48  59  59  48  48  40  36  60  69
14  57  24 133  99 108  60  56  24  18  12  48  53  61  60  80  73  52
48  24  48  61  49  48  96  48 108  48 140 108  89 111 120 102  60 132
48 100  48  54  60  17  48  99  48  48  48  48  89 112  60  84  48 288
48  54  48  89  67  65 116 158  99  19  26 113  48  60  48  48  48 122
158  48  48 133  16  99  24  12  52  37
#poner enter en la consola antes de avanzar para que cargue bien los datos

muertos<-scan()
1 2 1 2 1 1 1 1 1 1 2 2 1 1 2 2 1 1 2 2 2 1 2 1 1 1 2 2 2 1 1 2 2 1 1 1 1
2 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 2 1 2 1 1 1 1 1 1 1 1 1 1 1 1 1 2
 1 1 1 1 1 1 1 2 2 1 1 1 1 1 1 1 1 1 1 1 2 2 2 2 1 2 
 #poner enter en la consola antes de avanzar para que cargue bien los datos
 
car<-scan()
0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 1 1 0 1 0 1 0 0 1 0 0 0 0 0 0 1 0 0 0 0
 0 0 1 0 0 1 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
0 0 0 0 0 1 0 0 0 0 1 0 1 0 1 1 1 0 0 0 0 0 0 0 0 1
#poner enter en la consola antes de avanzar para que cargue bien los datos

car<-factor(car, labels=c("No", "Si"))

kaplan<-data.frame("Sobrevida"=sobrevida,"Muertos"= muertos,
                   "caracteristica"=car)
fit <- survfit(Surv(Sobrevida,Muertos) ~ caracteristica, data = kaplan)
fit3 <- survfit(Surv(sobrevida) ~ 1, data = kaplan)

ggsurvplot(
  fit, 
  data = kaplan, 
  size = 1,                 # change line size
  palette = c( "cadetblue3","firebrick", "chocolate", "forestgreen"),# custom color palettes
  #palette = c("mediumorchid3", "cadetblue3"),# custom color palettes
  conf.int = TRUE,          # Add confidence interval
  #title="HR in negative group: 0.14 (95% CI: 0.027 - 0.69) p<0.008",
  #pval = TRUE,              # Add p-value
  risk.table = TRUE,        # Add risk table
  risk.table.col = "strata",# Risk table color by groups
  #legend.labs = c("Positivo","Negativo"),    # Change legend labels
  legend=c("right"),
  risk.table.height = 0.25, # Useful to change when you have multiple groups
  ggtheme = theme_bw()  # Change ggplot2 theme
  #surv.median.line = c("v")
)


ggcompetingrisks(
  fit3,
  gnames = NULL,
  palette = c( "cadetblue3","firebrick"),# custom color palettes
  gsep = " ",
  multiple_panels = TRUE,
  coef = 1.96,
  conf.int = FALSE,
  title="Curvas de riesgo competitivo", 
  xlab="Tiempo",
  ylab="Probabilidad estimada",
  legend=c("right"),
  legend.labs = c("LR=0","LR=1")    # Change legend labels
)



########## Un ejemplo fuera de programa
library(car)
library(RColorBrewer)


# Primero el grafico
my_colors <- brewer.pal(nlevels(as.factor(data$cyl)), "Set2")
scatterplotMatrix(~mpg+disp+drat|cyl, data=data , reg.line="" , 
                  smoother="", col=my_colors , smoother.args=list(col="grey") , 
                  cex=1.5 , pch=c(15,16,17) , main="Scatter plot with Three Cylinder Options")



#un Scatterplot con todo
options(scipen=999)
library(ggplot2)
data("midwest", package = "ggplot2")
#View(midwest)
theme_set(theme_bw())

gg <- ggplot(midwest, aes(x=area, y=poptotal)) + 
  geom_point(aes(col=state, size=popdensity)) + 
  geom_smooth(method="loess", se=F) + xlim(c(0, 0.1)) + ylim(c(0, 500000)) + 
  labs(title="Area Vs Population", y="Population", x="Area", caption="Source: midwest", 
       color="")
gg


#para enchular los textos
gg + theme(plot.title=element_text(size=20, 
                                   face="bold", 
                                   family="American Typewriter",
                                   color="tomato",
                                   hjust=0.5,
                                   lineheight=1.2),  # title
           plot.subtitle=element_text(size=15, 
                                      family="American Typewriter",
                                      face="bold",
                                      hjust=0.5),  # subtitle
           plot.caption=element_text(size=15),  # caption
           axis.title.x=element_text(vjust=10,  
                                     size=15),  # X axis title
           axis.title.y=element_text(size=15),  # Y axis title
           axis.text.x=element_text(size=10, 
                                    angle = 30,
                                    vjust=.5),  # X axis text
           axis.text.y=element_text(size=10))  # Y axis text






